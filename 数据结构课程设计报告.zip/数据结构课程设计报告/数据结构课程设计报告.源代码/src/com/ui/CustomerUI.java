package com.ui;

import java.awt.Font;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import com.ui.Break;


import java.awt.Toolkit;
import java.awt.Color;


public class CustomerUI extends JFrame implements ActionListener{


	JFrame custoner=this;
	
	JButton btn2=new JButton("ȡ��");
	JButton btn3=new JButton("����");
	JButton btn4=new JButton("���");
	JButton btn6=new JButton("�޸�����");
	JButton btn7=new JButton("��ѯ���");
	JButton btn8=new JButton("����");
	JPanel ControlP=new JPanel(){public void paintComponent(java.awt.Graphics g){
		ImageIcon icon=new ImageIcon(this.getClass().getResource("main.jpg"));
		g.drawImage(icon.getImage(), 0, 0, icon.getImageObserver());
	}
};;

	public CustomerUI(String title) {
		super(title);

		init();
	}
	public void init() {
		ControlP.setLayout(null);
		getContentPane().add(ControlP);
	     
	     btn2.setForeground(Color.WHITE);
	     btn2.setBackground(Color.LIGHT_GRAY);
	     btn2.setBounds(550, 70, 250, 100);
	     btn2.setFont(new Font("����",Font.BOLD,30));
	     btn2.setForeground(Color.cyan);
	     btn2.setContentAreaFilled(false);
	     btn2.setContentAreaFilled(false);
	     btn2.setBorderPainted(false);
	     ControlP.add(btn2); 
	     btn3.setForeground(Color.WHITE);
	     btn3.setBackground(Color.LIGHT_GRAY);
	     btn3.setBounds(20, 170, 250, 100);
	     btn3.setFont(new Font("����",Font.BOLD,30));
	     btn3.setForeground(Color.cyan);
	     btn3.setContentAreaFilled(false);
	     btn3.setBorderPainted(false);
	     ControlP.add(btn3); 
	     btn4.setForeground(Color.WHITE);
	     btn4.setBackground(Color.LIGHT_GRAY);
	     btn4.setBounds(550, 170, 250, 100);
	     btn4.setFont(new Font("����",Font.BOLD,30));
	     btn4.setForeground(Color.cyan);
	     btn4.setContentAreaFilled(false);
	     btn4.setBorderPainted(false);
	     ControlP.add(btn4); 
	     btn6.setBackground(Color.LIGHT_GRAY);
	     btn6.setForeground(Color.WHITE);
	     btn6.setBounds(550, 270, 250, 100);
	     btn6.setFont(new Font("����",Font.BOLD,30));
	     btn6.setForeground(Color.cyan);
	     btn6.setContentAreaFilled(false);
	     btn6.setBorderPainted(false);
	     ControlP.add(btn6); 
	     btn7.setBackground(Color.LIGHT_GRAY);
	     btn7.setForeground(Color.WHITE);
	     btn7.setBounds(20, 70, 250, 100);
	     btn7.setFont(new Font("����",Font.BOLD,30));
	     btn7.setForeground(Color.cyan);
	     btn7.setContentAreaFilled(false);
	     btn7.setBorderPainted(false);
	     ControlP.add(btn7); 
	     btn8.setBackground(Color.LIGHT_GRAY);
	     btn8.setForeground(Color.WHITE);
	     btn8.setBounds(20, 270, 250, 100);
	     btn8.setFont(new Font("����",Font.BOLD,30));
	     btn8.setForeground(Color.cyan);
	     btn8.setContentAreaFilled(false);
	     btn8.setBorderPainted(false);
	     ControlP.add(btn8); 
		
		this.setBounds(350, 200, 847, 490);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		customerui=this;
		//����
		btn2.addActionListener(this);
		btn3.addActionListener(this);
		btn4.addActionListener(this);
		btn6.addActionListener(this);
		btn7.addActionListener(this);
		btn8.addActionListener(this);
	}
	@Override
	
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Object obj=e.getSource();
     
	if(obj==btn2) {
			
			custoner.setVisible(false);
			breakf=new Break("ȡ��");
		}else if(obj==btn3) {
			
			custoner.setVisible(false);
			transfer=new  TransferAccount("����");
		}else if(obj==btn4) {
			
			custoner.setVisible(false);
			deposit=new Deposit("���");
		}
	else if(obj==btn6) {
			
			custoner.setVisible(false);
			mima=new Mima("�޸�����");
		}else if(obj==btn7) {
			check=new Check("��ѯ���");
			custoner.setVisible(false);
		}else if(obj==btn8){
			Login.cusf.setVisible(false);
            Login.guif.setVisible(true);
            
		}
		
		
	}
	static JFrame customerui;
	static JFrame breakf;
	static JFrame search;
	static JFrame deposit;
	static JFrame transfer;
	static JFrame mima;
	static JFrame check;
	static JFrame print;
	
}

