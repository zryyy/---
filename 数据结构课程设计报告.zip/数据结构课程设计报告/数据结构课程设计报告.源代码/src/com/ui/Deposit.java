package com.ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;
import java.util.HashMap;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.clientData.Client;
import com.dataManger.ClientDb;
import com.db.Arith;


public class Deposit extends JFrame{

	
	JPanel contentPane = new JPanel(){
		public void paintComponent(java.awt.Graphics g){
			ImageIcon icon = new ImageIcon(this.getClass().getResource("9.jpeg"));
			g.drawImage(icon.getImage(), 0, 0, icon.getImageObserver());
		};
	};
	JLabel label = new JLabel("���");
	JLabel label_1 = new JLabel("����");
	JTextField textField  = new JTextField(10);
	JButton button = new JButton("ȷ��");
	JButton button_1 = new JButton("����");
	JLabel label_2 = new JLabel("");
	public Deposit(String title){
		super(title);
		init();
	}
	public void init(){
		contentPane.add(label);
		label.setBounds(225, 40,100, 30);
		label.setFont(new Font("����", Font.BOLD, 40));
		label.setForeground(Color.white);
		contentPane.add(label_1);
		label_1.setBounds(150, 90, 200, 30);
		label_1.setFont(new Font("����", Font.BOLD, 30));
		label_1.setForeground(Color.white);
		contentPane.add(label_2);
		label_2.setBounds(225, 120, 150, 20);
		label_2.setFont(new Font("����", Font.BOLD, 20));
		contentPane.add(textField);	
		textField.setBounds(280, 93, 118, 24);
		textField.setFont(new Font("����", Font.BOLD, 20));
		contentPane.add(button);
		button.setBounds(150, 180, 100, 27);
		button.setFont(new Font("����", Font.BOLD, 20));
		button.setForeground(Color.WHITE);
		button.setBorderPainted(false);
		button.setContentAreaFilled(false);
		contentPane.add(button_1);
		button_1.setBounds(300, 180, 100, 27);
		button_1.setFont(new Font("����", Font.BOLD, 20));
		button_1.setForeground(Color.WHITE);
		button_1.setBorderPainted(false);
		button_1.setContentAreaFilled(false);
	
		contentPane.setLayout(null);

		this.add(contentPane);
		this.setBounds(600, 200, 540, 300);
		this.setVisible(true);
		 this.setResizable(false);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CustomerUI.deposit.setVisible(false);
				CustomerUI.customerui.setVisible(true);
			}
		});
		
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String num = textField.getText();	
				double sum=Double.parseDouble(num);
				
				Client client = ClientDb.clients.get(Login.card);
				
			
					if(client.getCardNO().equals(Login.card)) {
						double temp=Arith.add(client.getMoney(), sum);
						client.setMoney(temp);
						ClientDb.saveData(client);
						
						JOptionPane.showMessageDialog(button, "���ɹ�");
						CustomerUI.deposit.setVisible(false);
						CustomerUI.customerui.setVisible(true);
						
					}
				}
			
		});
	}
	

}

