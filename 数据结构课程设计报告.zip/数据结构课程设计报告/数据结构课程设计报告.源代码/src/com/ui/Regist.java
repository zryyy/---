package com.ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.Set;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import com.clientData.Client;
import com.dataManger.ClientDb;

public class Regist extends JFrame{
	Client n;
	JPanel panel = new JPanel(){
		public void paintComponent(java.awt.Graphics g){
			ImageIcon icon = new ImageIcon(this.getClass().getResource("register.jpg"));
			g.drawImage(icon.getImage(), 0, 0, icon.getImageObserver());
		};
	};
	JLabel lblNewLabel = new JLabel("����");
	JButton btnNewButton = new JButton("����");
	JLabel lblNewLabel_1 = new JLabel("�û�����");
	JTextField textField = new JTextField("�������û���",20);
	JLabel lblNewLabel_2 = new JLabel("���룺");
	JPasswordField pwdpassword = new JPasswordField();
	JLabel lblNewLabel_4 = new JLabel("����֤�ţ�");
	JTextField textField_1 = new JTextField("����������֤��",20);
	JButton btnNewButton_1 = new JButton("����");
	public Regist(String title){
		super(title);
		init();
	}
	public void init(){
		 lblNewLabel.setLabelFor(this);
	 		lblNewLabel.setForeground(Color.black);
	 		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
	 		lblNewLabel.setFont(new Font("����", Font.BOLD, 27));
	 		lblNewLabel.setBounds(14, 13, 815, 32);
	 		panel.add(lblNewLabel);

		btnNewButton.setBounds(200, 300, 113, 40);
		btnNewButton.setFont(new Font("����",Font.BOLD, 20));
		btnNewButton.setContentAreaFilled(false);
		btnNewButton.setBorderPainted(false);
		panel.add(btnNewButton);
		lblNewLabel_1.setBounds(260, 80,  172, 70);
		lblNewLabel_1.setFont(new Font("����",Font.BOLD, 25));
		panel.add(lblNewLabel_1);
		lblNewLabel_1.setForeground(Color.black);
		textField.setBounds(400, 105, 150, 20);
		textField.setFont(new Font("����",Font.BOLD, 15));
		panel.add(textField);
		lblNewLabel_2.setBounds(260, 140,172,70);
		lblNewLabel_2.setForeground(Color.black);
		lblNewLabel_2.setFont(new Font("����",Font.BOLD, 25));
		panel.add(lblNewLabel_2);
		pwdpassword.setBounds(400, 165, 150, 20);
		pwdpassword.setFont(new Font("����",Font.BOLD, 10));
		panel.add(pwdpassword);
		lblNewLabel_4.setBounds(260,200, 172, 70);
		lblNewLabel_4.setFont(new Font("����",Font.BOLD, 25));
		panel.add(lblNewLabel_4);
		lblNewLabel_4.setForeground(Color.black);
		textField_1.setBounds(401, 225, 150, 20);
		textField_1.setFont(new Font("����",Font.BOLD, 15));
		panel.add(textField_1);
		btnNewButton_1.setBounds(530, 300, 113, 40);
		btnNewButton_1.setFont(new Font("����",Font.BOLD, 20));
		btnNewButton_1.setContentAreaFilled(false);
		btnNewButton_1.setBorderPainted(false);
		panel.add(btnNewButton_1);
		panel.setLayout(null);
		this.add(panel);
		this.setBounds(350, 200, 847, 490);
		this.setVisible(true);
		 this.setResizable(false);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		textField.addFocusListener(new FocusListener() {
			public void focusLost(FocusEvent e) {
				String txt = textField.getText();
				if(txt.trim().length()<=0){
					textField.setText("�������û���");
			    }
			}
			public void focusGained(FocusEvent e) {
				String txt = textField.getText();
				if("�������û���".equals(txt)){
			    textField.setText("");
				}
			}
		});
		textField_1.addFocusListener(new FocusListener() {
			public void focusLost(FocusEvent e) {
				String txt = textField_1.getText();
				if(txt.trim().length()<=0){
					textField_1.setText("����������֤��");
			    }
			}
			public void focusGained(FocusEvent e) {
				String txt = textField_1.getText();
				if("����������֤��".equals(txt)){
					textField_1.setText("");
				}
			}
		});
		//ע��
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cname = textField.getText();		
				String pwd = new String(pwdpassword.getPassword());
				String id = textField_1.getText();
				if(cname.equals("�������û���")||pwd.equals("")||id.equals("����������֤��")) {
					 JOptionPane.showMessageDialog(rootPane, "����дע����Ϣ");
				}else {
				Set<String> client =  ClientDb.clients.keySet();
				int random=(int)(Math.random()*100+1);
				String cardNO=String.valueOf(random);
				for(String c:client){
				   n=ClientDb.clients.get(c);
				  
				  if(cardNO.equals(n.getCardNO())) {
					  random=(int)(Math.random()*100+1);
					  cardNO=String.valueOf(random);
				  }
				 if(n.getiD().equals(id)){
					 JOptionPane.showMessageDialog(rootPane, "�û��Ѵ��ڣ�");
					 return;
				 }
				}
				Client cnew = new Client(cname,cardNO,pwd,id,1,0);
				ClientDb.clients.put(cardNO, cnew);
				
				ClientDb.saveData(ClientDb.clients);
				for(String c:client) {
					System.out.println(ClientDb.clients.get(c));
				}
				JOptionPane.showMessageDialog(rootPane, "ע��ɹ�������Ϊ��"+random);
				Login.registF.setVisible(false);
				Login.guif.setVisible(true);
				}
			}
		});
         //����
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login.registF.setVisible(false);
				Login.guif.setVisible(true);
			}
		});
	}



}
