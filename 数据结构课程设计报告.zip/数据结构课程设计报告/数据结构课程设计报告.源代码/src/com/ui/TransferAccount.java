package com.ui;

import java.awt.Color;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Collection;
import java.util.HashMap;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import com.clientData.Client;
import com.dataManger.ClientDb;
import com.db.Arith;



public class TransferAccount extends JFrame {
	public static String card;
	static String pwd;

	JPanel contentPane = new JPanel(){
		public void paintComponent(java.awt.Graphics g){
			ImageIcon icon = new ImageIcon(this.getClass().getResource("close.jpg"));
			g.drawImage(icon.getImage(), 0, 0, icon.getImageObserver());
		};
	};
	JLabel label = new JLabel("����");
	JLabel label_1 = new JLabel("���ţ�");
	JTextField textField  = new JTextField(10);
	JLabel label_2 = new JLabel("���룺");
	JPasswordField passwordField = new JPasswordField(10);
	JButton button = new JButton("ȷ��");
	JButton button_1 = new JButton("����");
	public TransferAccount(String title){
		super(title);
		init();
	}
	public void init(){
		contentPane.add(label);
		
		label.setBounds(225, 40,100, 30);
		label.setFont(new Font("����", Font.BOLD, 40));
		label.setForeground(Color.white);
		contentPane.add(label);
	
		label_1.setBounds(120, 90, 150, 20);
		label_1.setFont(new Font("����", Font.BOLD, 20));
		label_1.setForeground(Color.WHITE);
		contentPane.add(label_1);
		contentPane.add(textField);	
		textField.setBounds(239, 93, 150, 24);
		textField.setFont(new Font("����", Font.BOLD, 20));

		label_2.setBounds(120, 150, 150, 20);
		label_2.setFont(new Font("����", Font.BOLD, 20));
		label_2.setForeground(Color.WHITE);
		contentPane.add(label_2);
		contentPane.add(passwordField);	
		passwordField.setBounds(239, 150, 150, 24);
		passwordField.setFont(new Font("����", Font.BOLD, 20));
	
		contentPane.add(button);
		button.setBounds(150, 230, 120, 27);
		button.setFont(new Font("����", Font.BOLD, 20));
		button.setContentAreaFilled(false);
  	  button.setBorderPainted(false);
  	 
		contentPane.add(button_1);
		
		button_1.setBounds(300, 230, 120, 27);
		button_1.setFont(new Font("����", Font.BOLD, 20));
		button_1.setContentAreaFilled(false);
		button_1.setBorderPainted(false);
  	 
		
		contentPane.setLayout(null);

		this.add(contentPane);
		this.setBounds(600, 200, 540, 350);
		this.setVisible(true);
		 this.setResizable(false);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CustomerUI.transfer.setVisible(false);
				CustomerUI.customerui.setVisible(false);
			}
		});
		
		button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub			
			
				
				card = textField.getText();
 				pwd = new String(passwordField.getPassword());
				
 				
 				Client client = ClientDb.clients.get(card);  //**************************
 				

				if(client==null||!pwd.equals(client.getCardPwd())){
					JOptionPane.showMessageDialog(rootPane, "���Ż��������");
				}
				
				else {
					
					Client c=ClientDb.clients.get(Login.card);
					  double b = c.getMoney();
					  String  m=String.valueOf(b);
					ClientDb.clients.remove(card);
					ClientDb.saveData(ClientDb.clients);
					JOptionPane.showMessageDialog(rootPane, "����������������"+m+"Ԫ");
					
					CustomerUI.transfer.setVisible(false);
		            Login.guif.setVisible(true);
					
		  
					
				}
				
				 
					
				
				}
		});
	}

	
}